require 'active_support/all'
require 'pry'

require_relative 'author.rb'
require_relative 'book.rb'
require_relative 'published_book.rb'
require_relative 'reader.rb'
require_relative 'reader_with_book.rb'

# library manager
class LibraryManager
  attr_accessor :readers, :books, :readers_with_books

  def initialize(readers = [], books = [], readers_with_books = [])
    @readers_with_books = readers_with_books.uniq
    @readers = readers.uniq
    @books = books.uniq
    populate_statistics!
  end

  def new_book(author, title, price, pages_quantity, published_at)
    books << PublishedBook.new(author, title, price,
                               pages_quantity, published_at)
    populate_statistics!
  end

  def new_reader(name, reading_speed)
    readers << Reader.new(name, reading_speed)
    populate_statistics!
  end

  def give_book_to_reader(reader_name, book_title)
    book = books.find { |b| b.title == book_title }
    reader = readers.find { |r| r.name == reader_name }
    readers_with_books << ReaderWithBook.new(book, reader)
    populate_statistics!
  end

  def read_the_book(reader_name, duration)
    ReaderWithBook.find_reader_and_update_current_page(
      readers_with_books, reader_name, duration)
    pupulate_statistics!
  end

  def reader_notification(reader_name)
    reader = readers_with_books.find { |x| x.reader.name == reader_name }
    r = reader_notification_params(reader)
    <<-TEXT
Dear #{r[:name]}!
You should return a book "#{r[:book_title]}" authored by #{r[:book_author]} in #{r[:hours_left]} hours.
Otherwise you will be charged $#{r[:fine]} per hour.
By the way, you are on #{r[:cur_page]} page now and you need #{r[:to_finish]} hours to finish reading "#{r[:book_title]}"
TEXT
  end

  def librarian_notification
    l = librarian_notification_params
    <<-TEXT
Hello,
There are #{l[:books_count]} published books in the library.
There are #{l[:readers]} readers and #{l[:readers_with_books]} of them are reading the books.
#{l[:notifications]}
    TEXT
  end

  def statistics_notification
    s = statistics_notification_params
    <<-TEXT
Hello,
The library has: #{s[:books_count]} books, #{s[:authors_count]} authors, #{s[:readers_count]} readers
The most popular author is #{s[:author][0]}: #{s[:author][1]['pages']} pages has been read by #{s[:author][1]['readers']} readers in #{s[:author][1]['books']} books.
The most productive reader is #{s[:reader][0]}: he had read #{s[:reader][1]['pages']} pages in #{s[:reader][1]['books']} books authored by #{s[:reader][1]['authors'].size} authors.
The most popular book is \"#{s[:book][0]}\" authored by #{s[:book][1]['author']}: it had been read for #{format('%.2f', s[:book][1]['reading_hours']/2.0)} hours by #{s[:book][1]['readers'].size} readers.
    TEXT
  end

  private

  def reader_notification_params(reader)
    {
      name: "#{reader.reader.name}",
      book_title: "#{reader.amazing_book.title}",
      book_author: "#{reader.amazing_book.author.name}",
      hours_left: "#{count_hours_left(reader)}",
      fine: "#{reader.penalty_per_hour.round(2)}",
      cur_page: "#{reader.current_page}",
      to_finish: "#{format('%.2f', reader.time_to_finish)}"
    }
  end

  def count_hours_left(reader)
    ((reader.return_date - DateTime.now.new_offset(0)) * 24.0).round
  end

  def librarian_notification_params
    stat = @statistics
    {
      books_count: "#{stat['book_titles'].size}",
      readers: "#{stat['readers'].size}",
      readers_with_books: "#{readers_with_books.size}",
      notifications: create_notifications_for_readers
    }
  end

  def create_notifications_for_readers
    result = ''
    readers_with_books.each do |r|
      result += r.reader.name.to_s + ' is reading ' \
                  "\"#{r.amazing_book.title}\"" \
                  " - should return on #{r.return_date.to_date} at "\
                  "#{r.return_date.to_time.strftime('%l%P')} - "\
                  "#{format('%.2f', r.time_to_finish)} "\
                  "hours of reading is needed to finish.\n"
    end
    result.chomp
  end

  def statistics_notification_params
    stat = @statistics
    {
      books_count: "#{stat['book_titles'].size}",
      authors_count: "#{stat['authors'].size}",
      readers_count: "#{stat['readers'].size}",
      author: most_popular_author,
      reader: most_productive_reader,
      book: most_popular_book
    }
  end

  def create_statistics_hash
    @statistics = {}
    @statistics['readers'] = {}
    @statistics['book_titles'] = {}
    @statistics['authors'] = {}
  end

  def populate_statistics!
    create_statistics_hash
    populate_readers
    populate_book_titles
    populate_book_titles
    populate_authors
    @statistics
  end

  def populate_readers
    readers_with_books.each do |r|
      stat = @statistics['readers'][r.reader.name] ||=
        { 'pages' => 0, 'books' => 0, 'authors' => [] }
      stat['pages'] += r.current_page
      stat['authors'] |= [r.amazing_book.author.name]
      stat['books'] += 1
    end
    populate_readers_without_books
  end

  def populate_readers_without_books
    readers.each do |r|
      @statistics['readers'][r.name] ||=
        { 'pages' => 0, 'books' => 0, 'authors' => [] }
    end
  end

  def populate_book_titles
    readers_with_books.each do |r|
      stat = @statistics['book_titles'][r.amazing_book.title] ||=
        { 'author' => '', 'reading_hours' => 0, 'readers' => [] }
      stat['author'] = r.amazing_book.author.name
      stat['reading_hours'] += r.reading_hours.to_f
      stat['readers'] |= [r.reader.name]
    end
    populate_book_titles_without_readers
  end

  def populate_book_titles_without_readers
    books.each do |b|
      stat = @statistics['book_titles'][b.title] ||=
        { 'author' => '', 'reading_hours' => 0, 'readers' => [] }
      stat['author'] = b.author.name
    end
  end

  def populate_authors
    readers_with_books.each do |r|
      stat = @statistics['authors'][r.amazing_book.author.name] ||=
        { 'pages' => 0, 'readers' => 0, 'books' => 0 }
      stat['pages'] += r.current_page
      stat['readers'] += 1
      stat['books'] += 1
    end
    populate_authors_without_readers
  end

  def populate_authors_without_readers
    (books - books_being_read).each do |b|
      stat = @statistics['authors'][b.author.name] ||=
        { 'pages' => 0, 'readers' => 0, 'books' => 0 }
      stat['books'] += 1
    end
  end

  def most_popular_author
    @statistics['authors'].sort_by do |_, v|
      [v['pages'].to_i]
    end.last
  end

  def most_productive_reader
    @statistics['readers'].sort_by do |_, v|
      [v['pages'].to_i]
    end.last
  end

  def most_popular_book
    @statistics['book_titles'].sort_by do |_, v|
      [v['reading_hours'].to_i]
    end.last
  end

  def books_being_read
    readers_with_books.map(&:amazing_book)
  end
end
