require_relative 'library_manager.rb'

describe LibraryManager do
  let(:leo_tolstoy) do
    Author.new(1828, 1910, 'Leo Tolstoy')
  end
  let(:oscar_wilde) { Author.new(1854, 1900, 'Oscar Wilde') }
  let(:war_and_peace) do
    PublishedBook.new(leo_tolstoy, 'War and Peace', 1400, 3280, 1996)
  end
  let(:ivan) { Reader.new('Ivan Testenko', 16) }
  let(:ivan_testenko) do
    ReaderWithBook.new(war_and_peace, ivan, 328,
                       (DateTime.now.new_offset(0) + 2.days))
  end
  subject(:manager) { LibraryManager.new([], [], [ivan_testenko]) }

  it 'should compose reader notification' do
    expect(manager.reader_notification('Ivan Testenko')). to eq <<-TEXT
Dear Ivan Testenko!
You should return a book "War and Peace" authored by Leo Tolstoy in 48 hours.
Otherwise you will be charged $16.44 per hour.
By the way, you are on 328 page now and you need 184.50 hours to finish reading "War and Peace"
TEXT
  end

  it 'should compose librarian notification' do
    expect(manager.librarian_notification). to eq <<-TEXT
Hello,
There are 1 published books in the library.
There are 1 readers and 1 of them are reading the books.
Ivan Testenko is reading "War and Peace" - should return on 2015-07-10 at #{(DateTime.now.new_offset(0) + 2.days).to_time.strftime('%l%P')} - 184.50 hours of reading is needed to finish.
TEXT
  end

  it 'should compose statistics notification' do
    expect(manager.statistics_notification). to eq <<-TEXT
Hello,
The library has: 1 books, 1 authors, 1 readers
The most popular author is Leo Tolstoy: 328 pages has been read by 1 readers in 1 books.
The most productive reader is Ivan Testenko: he had read 328 pages in 1 books authored by 1 authors.
The most popular book is "War and Peace" authored by Leo Tolstoy: it had been read for 20.50 hours by 1 readers.
TEXT
  end
end
