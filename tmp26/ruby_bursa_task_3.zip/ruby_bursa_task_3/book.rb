class Book

  attr_accessor :author, :title

  def initialize author, title
    @author, @title = author, title
  end

end
