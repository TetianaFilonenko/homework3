require './library_manager.rb'

describe LibraryManager do
	let(:leo_tolstoy) do
    Author.new(1828, 1910, 'Leo Tolstoy' ) 
  end
  let!(:oscar_wilde) { Author.new(1854, 1900, 'Oscar Wilde') }
  let!(:war_and_peace) { PublishedBook.new(leo_tolstoy, 'War and Peace', 1400, 3280, 1996) }
  let!(:dorian_grey) {PublishedBook.new(oscar_wilde, 'The Picture of Dorian Grey', 1400, 208, 1890) }
  let!(:nikolay)  {Reader.new('Nikolay Vasiliev', 20)}
  let!(:vasiliev_nikolay) {ReaderWithBook.new(dorian_grey, nikolay, 100, (DateTime.now + 24.hours))}

  let!(:ivan) {Reader.new('Ivan Testenko', 16)}
  let!(:ivan_testenko) { ReaderWithBook.new(war_and_peace, ivan, 328, (DateTime.now.new_offset(0) + 2.days)) }
  let!(:manager) { LibraryManager.new([ivan, nikolay],[war_and_peace, dorian_grey], [ivan_testenko]) }
  #binding.pry
 # let(:leo_tolstoy) {Author.new(1828, 1910, 'Leo Tolstoy')}
  #let(:oscar_wilde) { Author.new(1854, 1900, 'Oscar Wilde')}
  #let(:stendhal) {Author.new(1783, 1842, 'Stendhal')}
  #let(:david_black) {Author.new(1969, 2059, 'David A.Black')}
  

  #tolstoy_book_1 = PublishedBook.new(leo_tolstoy, 'War and Peace', 1400, 3280, 1996)
  #tolstoy_book_2 = PublishedBook.new(leo_tolstoy, 'Anna Karenina', 1300, 864, 2011)
  #wilde_book = PublishedBook.new(oskar_wilde, 'The Picture of Dorian Gray', 1200, 328, 2004)
  #stendhal_book = PublishedBook.new(stendhal, 'Red and Black', 1100, 400, 2010)
  #ruby_book = PublishedBook.new(david_black, 'The Well-Grounded Rubyist', 2000, 520, 2009)

  #testenko = Reader.new('Ivan Testenko', 16)
  #pupkin = Reader.new('Vasiliy Pupkin', 17)
  #obama = Reader.new('Barak Obama', 25)
  #boxer = Reader.new('Vitaliy Klichko', 10)
  #dumbass = Reader.new('Victor Yanukovich', 1)
  #gunpowder = Reader.new('Petr Poroshenko', 18)

  #manager = LibraryManager.new([], [], [testenko])
  #library = LibraryManager.new.new_book(leo_tolstoy)
  it 'should compose reader notification' do
    expect(manager.reader_notification("Ivan Testenko")). to eq <<-TEXT
Dear Ivan Testenko!

You should return a book "War and Peace" authored by Leo Tolstoy in 36 hours.
Otherwise you will be charged $12.3 per hour.
By the way, you are on 333 page now and you need 5.4 hours to finish reading "War and Peace"
TEXT
  end

  it 'should compose librarian notification' do
    expect(manager.librarian_notification). to eq <<-TEXT
Hello,

There are 5 published books in the library.
manager.books.count
There are 6 readers and 3 of them are reading the books.
manager.readers.count manager.readers_with_books.count
Ivan Testenko is reading "War and Peace" - should return on 2015-07-04 at 10am - 5.0 hours of reading is needed to finish.
Vasiliy Pupkin is reading "Red and Black" - should return on 2015-07-12 at 7pm  - 12.7 hours of reading is needed to finish.
Barak Obama is reading "The Well-Grounded Rubyist" - should return on 2015-07-10 at 12pm  - 44.5 hours of reading is needed to finish.
TEXT

  end

  it 'should compose statistics notification' do
    expect(manager.statistics_notification). to eq <<-TEXT
Hello,

The library has: 5 books, 4 authors, 6 readers
The most popular author is Leo Tolstoy: 2450 pages has been read in 2 books by 4 readers.
The most productive reader is Ivan Testenko: he had read 1040 pages in 3 books authored by 3 authors.
The most popular book is "The Well-Grounded Rubyist" authored by David A. Black: it had been read for 123.0 hours by 5 readers.
TEXT
  end
  
end
