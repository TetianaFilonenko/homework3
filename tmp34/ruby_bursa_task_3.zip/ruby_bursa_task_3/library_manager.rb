require 'active_support/all'
require 'pry'

require_relative 'author.rb'
require_relative 'book.rb'
require_relative 'published_book.rb'
require_relative 'reader.rb'
require_relative 'reader_with_book.rb'

class LibraryManager

  attr_accessor :readers, :books, :readers_with_books

  def initialize readers = [], books = [], readers_with_books = []
    @readers_with_books = readers_with_books
    @readers = readers
    @books = books
    @statistics = {}
    populate_statistics!
  end

  def new_book author, title, price, pages_quantity, published_at

  end

  def new_reader  name, reading_speed

  end

  def give_book_to_reader reader_name, book_title

  end

  def read_the_book reader_name, duration
    ReaderWithBook.find_reader_and_update_current_page(@readers_with_books, reader_name, duration)
  end

  def reader_notification name
    current_reader = readers_with_books.find{|r| r.reader.name == name }
    <<-TEXT 
Dear #{current_reader.reader.name}!
You should return a book "#{current_reader.amazing_book.title}" authored by #{current_reader.amazing_book.author.name} in #{current_reader.hours_overdue} hours.
Otherwise you will be charged $#{current_reader.amazing_book.penalty_per_hour} per hour.
By the way, you are on #{current_reader.current_page} page now and you need #{current_reader.time_to_finish} hours to finish reading "#{current_reader.amazing_book.title}"
TEXT
  end

  def librarian_notification   
  
  reader_names = readers_with_books.map { |r| r.reader.name }
  readers_book_titles = readers_with_books.map { |r| r.amazing_book.title }
  retutn_dates = readers_with_books.map { |r| r.return_date.strftime("%F") }
  retutn_times = readers_with_books.map { |r| r.return_date.strftime("%l%P") }
  time_to_finish = readers_with_books.map { |r| r.time_to_finish }
 
  s = String.new
  i = 0
  loop do 
    if retutn_times[i].at(0) == " "
        s += "#{reader_names[i]} is reading \"#{readers_book_titles[i]}\" - should return on #{retutn_dates[i]} at#{retutn_times[i]} - #{time_to_finish[i]} hours of reading is needed to finish.\n"
    else
        s += "#{reader_names[i]} is reading \"#{readers_book_titles[i]}\" - should return on #{retutn_dates[i]} at #{retutn_times[i]} - #{time_to_finish[i]} hours of reading is needed to finish.\n"
   end    
    i += 1
    break if i == readers_with_books.count
  end

  "Hello,\nThere are #{books.count} published books in the library.\nThere are #{readers.count} readers and #{readers_with_books.count} of them are reading the books.\n" + s

  end

  def statistics_notification

author_names = books.map { |b| b.author.name }
author_names = author_names.uniq

readers_book_authors = readers_with_books.map { |r| r.amazing_book.author.name }
popular_author = readers_book_authors.each_with_object(Hash.new(0)) { |author,counts| counts[author] +=1 }
popular_author_name = popular_author.max_by{|k, v| v}

read_pages_of_popular_book = 0
i = 0
loop do
  if readers_with_books[i].amazing_book.author.name == popular_author_name[0]
    read_pages_of_popular_book += (readers_with_books[i].amazing_book.pages_quantity - readers_with_books[i].current_page)
  end
  i += 1
  break if i == readers_with_books.count
end

populate_statistics!

    "Hello,
The library has: #{books.count} books, #{author_names.count} authors, #{readers.count} readers
The most popular author is #{popular_author_name[0]}: #{read_pages_of_popular_book} pages has been read in #{popular_author_name[1]} books by #{popular_author_name[1]} readers.
The most productive reader is Ivan Testenko: he had read 1040 pages in 3 books authored by 3 authors.
The most popular book is \"The Well-Grounded Rubyist\" authored by David A. Black: it had been read for 123.0 hours by 5 readers."



end

  private

  def reader_notification_params

  end

  def librarian_notification_params

  end

  def statistics_notification_params

  end

  def populate_statistics!
     
   readers_with_books.each do |r|

     @statistics["readers"] ||= {}
     @statistics["readers"][r.reader.name] ||= {"pages" => 0, "books" => 0, "authors" => []}
     @statistics["readers"][r.reader.name]["pages"] = r.current_page
     @statistics["readers"][r.reader.name]["authors"] |= [r.amazing_book.author.name]
     @statistics["readers"][r.reader.name]["books"] = 1

     @statistics["book_titles"] ||= {}
     @statistics["book_titles"][r.amazing_book.title] ||= {"author" => "", "reading_hours" => 0, "readers" => []}
     @statistics["book_titles"][r.amazing_book.title]["author"] = r.amazing_book.author.name
     @statistics["book_titles"][r.amazing_book.title]["reading_hours"] += r.reading_hours
     @statistics["book_titles"][r.amazing_book.title]["readers" ] |= [r.reader.name]

     @statistics["authors"] ||= {}
     @statistics["authors"][r.amazing_book.author.name] ||= {"pages" => 0, "readers" => [], "books" => 0}
     @statistics["authors"][r.amazing_book.author.name]["pages"] += (r.amazing_book.pages_quantity/2)
     @statistics["authors"][r.amazing_book.author.name]["books"] += 1
     @statistics["authors"][r.amazing_book.author.name]["readers"] |= [r.reader.name]

    end
    @statistics
  
  end

  def statistics_sample
    {
      "readers" => {
        "Ivan Testenko" => {
          "pages" => 1040, 
          "books" => 3, 
          "authors" => ["David A. Black", "Leo Tolstoy"]
          }
        },
      "book_titles" => {
        "The Well-Grounded Rubyist" => {
          "author" => "David A. Black", 
          "reading_hours" => 123, 
          "readers" => ["Ivan Testenko"]
          }
        },
      "authors" => {
        "Leo Tolstoy" => {
          "pages" => 123, 
          "readers" => 4, 
          "books" => 3
          }
        }
    }
  end

end