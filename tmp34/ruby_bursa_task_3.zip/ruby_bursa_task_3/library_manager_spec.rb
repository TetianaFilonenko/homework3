require 'active_support/all'
require 'pry'
require './library_manager.rb'
require './author.rb'
require './book.rb'
require './published_book.rb'
require './reader.rb'
require './reader_with_book.rb'


describe LibraryManager do

  let(:leo_tolstoy) { Author.new(1828, 1910, 'Leo Tolstoy' ) }
  let(:giovanni_boccaccio) { Author.new(1313, 1375, 'Giovanni Boccaccio') }
  let(:william_shakespeare) { Author.new(1564, 1616, 'William Shakespeare') }
  let(:oscar_wilde) { Author.new(1854, 1900, 'Oscar Wilde') }

  let(:war_and_peace) { PublishedBook.new(leo_tolstoy, 'War and Peace', 1400, 3280, 1996) }
  let(:dekameron) { PublishedBook.new(giovanni_boccaccio, 'Dekameron', 1400, 560, 1997) }
  let(:anna_karenina) { PublishedBook.new(leo_tolstoy, 'Anna Karenina', 1400, 780, 2014) }
  let(:gamlet) { PublishedBook.new(william_shakespeare, 'Gamlet', 1400, 340, 2015) }
  let(:dorian) { PublishedBook.new(oscar_wilde, 'Dorian', 1400, 278, 1990) }

  let(:ivan) {Reader.new('Ivan Testenko', 16)}
  let(:olga) {Reader.new('Olga Tkachenko', 16)}
  let(:roman) {Reader.new('Roman Timoshenko', 16)}
  let(:oleg) {Reader.new('Oleg Romanenko', 16)}
  let(:egor) {Reader.new('Egor Ivanenko', 16)}
  let(:lada) {Reader.new('Lada Petrenko', 16)}

  let(:ivan_testenko) { ReaderWithBook.new(war_and_peace, ivan, 100, (DateTime.now.new_offset(0) + 2.days)) }
  let(:olga_tkachenko) { ReaderWithBook.new(anna_karenina, olga, 200, (DateTime.now.new_offset(0) + 3.days + 3.hours)) }
  let(:egor_ivanenko) { ReaderWithBook.new(gamlet, egor, 300, (DateTime.now.new_offset(0) + 4.days)) }

  let(:manager) { LibraryManager.new(
    [ivan, olga, roman, oleg, egor, lada],
    [war_and_peace, dekameron, anna_karenina, gamlet, dorian], 
    [ivan_testenko, olga_tkachenko, egor_ivanenko]) }


 it 'should compose reader notification' do
    expect(manager.reader_notification("Ivan Testenko")). to eq <<-TEXT
Dear Ivan Testenko!
You should return a book "War and Peace" authored by Leo Tolstoy in 48.0 hours.
Otherwise you will be charged $16.34 per hour.
By the way, you are on 100 page now and you need 198.75 hours to finish reading "War and Peace"
TEXT
  end

  it 'should compose librarian notification' do
    expect(manager.librarian_notification). to eq <<-TEXT
Hello,
There are 5 published books in the library.
There are 6 readers and 3 of them are reading the books.
Ivan Testenko is reading "War and Peace" - should return on 2015-07-10 at 8pm - 198.75 hours of reading is needed to finish.
Olga Tkachenko is reading "Anna Karenina" - should return on 2015-07-11 at 11pm - 36.25 hours of reading is needed to finish.
Egor Ivanenko is reading "Gamlet" - should return on 2015-07-12 at 8pm - 2.5 hours of reading is needed to finish.
TEXT
  end

  it 'should compose statistics notification' do
    expect(manager.statistics_notification). to eq <<-TEXT
Hello,
The library has: 5 books, 4 authors, 6 readers
The most popular author is Leo Tolstoy: 2450 pages has been read in 2 books by 4 readers.
The most productive reader is Ivan Testenko: he had read 1040 pages in 3 books authored by 3 authors.
The most popular book is "The Well-Grounded Rubyist" authored by David A. Black: it had been read for 123.0 hours by 5 readers.
TEXT
  end
  
end